#
# Copyright (C) 2024 by IamDvis@Github, < https://github.com/IamDvis >.
#
# This file is part of < https://github.com/IamDvis/DV-FILESTORE > project,
# and is released under the MIT License.
# Please see < https://github.com/IamDvis/DV-FILESTORE/blob/master/LICENSE >
#
# All rights reserved.

from pyrogram.errors import InputUserDeactivated, UserNotParticipant, FloodWait, UserIsBlocked, PeerIdInvalid
from plugins.dbusers import db
from pyrogram import Client, filters
from config import ADMINS
import asyncio
import datetime
import time
import logging

# This file is part of < https://github.com/IamDvis/DV-FILESTORE > project,
# and is released under the MIT License.
# Please see < https://github.com/IamDvis/DV-FILESTORE/blob/master/LICENSE >

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# This file is part of < https://github.com/IamDvis/DV-FILESTORE > project,
# and is released under the MIT License.
# Please see < https://github.com/IamDvis/DV-FILESTORE/blob/master/LICENSE >

async def broadcast_messages(user_id, message):
    try:
        await message.copy(chat_id=user_id)
        return True, "Success"
    except FloodWait as e:
        await asyncio.sleep(e.x)
        return await broadcast_messages(user_id, message)
    except InputUserDeactivated:
        await db.delete_user(int(user_id))
        logging.info(f"{user_id}-Removed from Database, since deleted account.")
        return False, "Deleted"
    except UserIsBlocked:
        logging.info(f"{user_id} -Blocked the bot.")
        return False, "Blocked"
    except PeerIdInvalid:
        await db.delete_user(int(user_id))
        logging.info(f"{user_id} - PeerIdInvalid")
        return False, "Error"
    except Exception as e:
        return False, "Error"

# This file is part of < https://github.com/IamDvis/DV-FILESTORE > project,
# and is released under the MIT License.
# Please see < https://github.com/IamDvis/DV-FILESTORE/blob/master/LICENSE >


@Client.on_message(filters.command("broadcast") & filters.user(ADMINS) & filters.reply)
async def verupikkals(bot, message):
    users = await db.get_all_users()
    b_msg = message.reply_to_message
    sts = await message.reply_text(
        text='Broadcasting your messages...'
    )
    start_time = time.time()
    total_users = await db.total_users_count()
    done = 0
    blocked = 0
    deleted = 0
    failed =0

# This file is part of < https://github.com/IamDvis/DV-FILESTORE > project,
# and is released under the MIT License.
# Please see < https://github.com/IamDvis/DV-FILESTORE/blob/master/LICENSE >

    success = 0
    async for user in users:
        if 'id' in user:
            pti, sh = await broadcast_messages(int(user['id']), b_msg)
            if pti:
                success += 1
            elif pti == False:
                if sh == "Blocked":
                    blocked += 1
                elif sh == "Deleted":
                    deleted += 1
                elif sh == "Error":
                    failed += 1
            done += 1
            if not done % 20:
                await sts.edit(f"Broadcast in progress:\n\nTotal Users {total_users}\nCompleted: {done} / {total_users}\nSuccess: {success}\nBlocked: {blocked}\nDeleted: {deleted}")    
        else:
            # Handle the case where 'id' key is missing in the user dictionary
            done += 1
            failed += 1
            if not done % 20:
                await sts.edit(f"Broadcast in progress:\n\nTotal Users {total_users}\nCompleted: {done} / {total_users}\nSuccess: {success}\nBlocked: {blocked}\nDeleted: {deleted}")    
    
    time_taken = datetime.timedelta(seconds=int(time.time()-start_time))
    await sts.edit(f"Broadcast Completed:\nCompleted in {time_taken} seconds.\n\nTotal Users {total_users}\nCompleted: {done} / {total_users}\nSuccess: {success}\nBlocked: {blocked}\nDeleted: {deleted}")

# This file is part of < https://github.com/IamDvis/DV-FILESTORE > project,
# and is released under the MIT License.
# Please see < https://github.com/IamDvis/DV-FILESTORE/blob/master/LICENSE >

